class WinjStream:
	pass