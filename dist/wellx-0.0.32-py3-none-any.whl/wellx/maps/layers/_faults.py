def faults():

	pass