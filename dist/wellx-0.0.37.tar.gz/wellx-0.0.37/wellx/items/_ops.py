from dataclasses import dataclass

@dataclass
class WellTest:
	pass

@dataclass
class Temperature:
	pass

@dataclass
class PLT:
	pass

@dataclass
class Tracers:
	pass