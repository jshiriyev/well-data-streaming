from dataclasses import dataclass, fields

import numpy as np

@dataclass
class Top:

    formation       : list[str]
    depth           : np.ndarray
    facecolor       : list[str] = None
    text_visibility : np.ndarray = None

    @staticmethod
    def fields() -> list:
        return [field.name for field in fields(Top)]