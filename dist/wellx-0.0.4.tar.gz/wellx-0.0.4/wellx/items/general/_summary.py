from dataclasses import dataclass

@dataclass
class Summary:
    """It is an executive summary text for a well."""
    text    : str