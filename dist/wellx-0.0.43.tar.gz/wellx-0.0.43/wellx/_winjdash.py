class WInjDash:
	pass