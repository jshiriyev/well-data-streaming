class Intervens():

	pass