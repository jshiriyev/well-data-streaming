class Intervs():

	pass